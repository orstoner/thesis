##############################
## Household Air Pollution: ##
##   A Hierarchical Model   ##
##############################

#############
# Contents: #
#############

# 0. Set up the functions and data.
# 1. Produce some plots of the data.
# 2. Run the model and produce some plots of fuel usage.
# 3. Perform some basic model checking.
# 4. Do the out-of-sample prediction experiment.
# 5. Output the fuel usage plots.

############
# 0. Setup #
############

# The following packages will need to be installed and loaded:
library(nimble)
library(ggplot2)
library(tidyverse)
library(coda)
library(gridExtra)
library(grid)
library(viridis)

# Colour pallette for plotting.
vp=viridis_pal(option='A',begin=0.2,end=0.8)(6)

# Random number generator seeds (for each chain).
seed1=c(874326,383625,256846,383790) # For generating initial values.
seed2=c(642647,147376,368742,868372) # For MCMC.

# Load in the data and source the scripts.
load('HAP_Data.RData')
source('HAP_Data_Setup.R') # Script for loading in and preparing the data for modelling. 
source('HAP_Functions.R') # Script containing a function for generating intial values and Beta-Binomial functions.
source('HAP_Model.R') # Script containing a function to run the model.
source('HAP_Plots.R') # Script containing plotting functions.

# Define the fuel names.
fuel_names=c('Wood','Charcoal','Coal','Cropwaste','Dung','Electricity','L.P.G.','Kerosene')

#################
# 1. Data plots #
#################

ggplot(model_data$overall, aes(x=wood_scaled,y=..density..,fill=region)) +
  stat_density(adjust=1) +
  labs(
    title = "Use of Wood for Cooking by Region",
    subtitle = "All Surveys (1990-2016)", 
    caption = "Source: Household Energy Database 2016 (WHO)",
    x = 'Proportion of Respondents Using Wood',
    y = 'Density'
  ) +
  theme(
    text = element_text(color = "#22211d"), 
    plot.background = element_rect(fill = "#f5f5f2", color = NA), 
    panel.background = element_rect(fill = "#f5f5f2", color = NA), 
    legend.background = element_rect(fill = "#f5f5f2", color = NA),
    
    plot.title = element_text(size= 16, hjust=0.01, color = "#4e4d47", margin = margin(b = -0.1, t = 0.4, l = 2, unit = "cm")),
    plot.subtitle = element_text(size= 12, hjust=0.01, color = "#4e4d47", margin = margin(b = -0.1, t = 0.43, l = 2, unit = "cm")),
    plot.caption = element_text( size=10, color = "#4e4d47", margin = margin(b = 0,t=0.3, unit = "cm") ),
    panel.grid.major = element_blank(), panel.grid.minor = element_blank()
  )+
  scale_fill_viridis(option='A',discrete=TRUE,begin=0.2,end=0.8,direction=-1,name='WHO Region')
ggsave('Plots/region_wood.pdf',width=7.5,height=4.5)

####################
# 2. Run the model #
####################

# To proceed, do one of the following (delete # where appropriate):

# 1. Run the model for the full duration (approximately 24 hours and over 32GB of system memory usage).
all_samples=run_model(model_data,niter=80000,nburnin=40000,nchains=4,thin=10)

# 2. Run the model for a reduced number of iterations (approximately 2 hours).
# Increase the thin argument to 16 for reduced memory usage.
# all_samples=run_model(model_data,niter=8000,nburnin=4000,nchains=4,thin=1)

# The fuel_plots() function can be used to produce various plots from the model.
fuel_plots('India',all_samples$processed_samples,model_data,sampling_bias = TRUE,type='survey')

# The first argument is the name of the country to plot. Please see country_info$country for possible names.

# The sampling_bias argument controls whether or not the estimated sampling bias in the
# proportion of urban/rural respondents should be included in the simulations. Generally,
# we want to include this when we are checking the model can reproduce the observed data and
# we want to ignore it when making inference for the fuel usage in the whole population.

# Setting type='survey' tells the function to simulate new survey observations
# from the Generalized-Dirichlet-Multinomial model, therefore taking into account sampling variation,
# while setting type='underlying' tells the function to only plot the underlying fuel usage in the country.

# Black points represent surveys which did not meet the 'completeness' criteria.

# Predictions interval plots for fuel surveys (including sampling bias):
pdf('Plots/ethiopia.pdf',width=12,height=7.5)
fuel_plots('Ethiopia',all_samples$processed_samples,model_data,sampling_bias = TRUE,type='survey')
dev.off()

pdf('Plots/south_africa.pdf',width=12,height=7.5)
fuel_plots('South Africa',all_samples$processed_samples,model_data,sampling_bias = TRUE,type='survey')
dev.off()

# Prediction interval plots for the underlying fuel usage:
fuel_plots('Ethiopia',all_samples$processed_samples,model_data,sampling_bias = FALSE,type='underlying')
fuel_plots('South Africa',all_samples$processed_samples,model_data,sampling_bias = FALSE,type='underlying')

# The proportion_plot() function can be used to plot the model's estimate of the mean proportion of 
# urban respondents for a given country:
india=proportion_plot('India',all_samples$processed_samples,model_data,colour=vp[2])
malawi=proportion_plot('Malawi',all_samples$processed_samples,model_data,colour=vp[4])
urban_proportion=arrangeGrob(india,malawi,nrow=1)
ggsave('Plots/urban_proportion.pdf',urban_proportion,width=10.5,height=3.25)

#####################
# 3. Model checking #
#####################

# Check convergence of the country effects:
delta_diag=gelman.diag(all_samples$mcmc[,which(dimnames(all_samples$mcmc$chain1)[[2]]=='delta[1, 1, 1, 1]'):
                                                   which(dimnames(all_samples$mcmc$chain1)[[2]]=='delta[194, 2, 2, 8]')],
                       multivariate = FALSE,autoburnin = FALSE)
pi_diag=gelman.diag(lapply(all_samples$mcmc[,which(dimnames(all_samples$mcmc$chain1)[[2]]=='pi[1]'):
                                              which(dimnames(all_samples$mcmc$chain1)[[2]]==paste('pi[',dim(model_data$urban)[1],']',sep=''))],logit),
                    multivariate = FALSE,autoburnin = FALSE)
epsilon_diag=gelman.diag(all_samples$mcmc[,which(dimnames(all_samples$mcmc$chain1)[[2]]=='epsilon[1, 1, 1]'):
                                            which(dimnames(all_samples$mcmc$chain1)[[2]]=='epsilon[194, 3, 8]')],
                         multivariate = FALSE,autoburnin = FALSE)

delta_hist=psrf_hist(delta_diag$psrf[,1],colour=vp[2],breaks=seq(1,1.5,0.02),x_ = c(1,1.5),
          x_label='P.S.R.F.',title='Intercept and Slope Effects')
pi_hist=psrf_hist(pi_diag$psrf[,1],colour=vp[3],breaks=seq(1,1.5,0.02),x_ = c(1,1.5),
          x_label='P.S.R.F.',title='Urban Proportions')
epsilon_hist=psrf_hist(epsilon_diag$psrf[,1],colour=vp[4],breaks=seq(1,1.5,0.02),x_ = c(1,1.5),
          x_label='P.S.R.F.',title='Variance Effects')
psrf=arrangeGrob(delta_hist,pi_hist,epsilon_hist,nrow=1)
ggsave('Plots/psrf.pdf',psrf,width=12,height=3)

# The fitted_values() function can be used to produce fitted values plots (with prediction
# interval coverages) for one or more fuels.

# The first argument is the name(s) of the fuel(s) to plot (see fuel_names).

# An optional argument no_overall can be used to prevent the overall values being plotted
# if set to TRUE.

# Produces two pages for some reason.
pdf('Plots/wood_fit.pdf',width=12,height=3.75)
fitted_values('Wood',all_samples$replicates,model_data,title='All Surveys (1990-2016)')
dev.off()

pdf('Plots/wood-coal.pdf',width=12,height=9)
fitted_values(fuel_names[1:4],all_samples$replicates,model_data,title='All Surveys (1990-2016)')
dev.off()

pdf('Plots/dung-kerosene.pdf',width=12,height=9)
fitted_values(fuel_names[5:8],all_samples$replicates,model_data,title='All Surveys (1990-2016)')
dev.off()

#############################
# 4. Forecasting experiment #
#############################

cut_off <- 2012 # Remove surveys from after this year.
experiment_data <- lapply(model_data,function(x){
  y=x
  y[y$year>cut_off,9:26]=NA
  return(y)
})

# Run the model with the truncated data.
experiment_samples=run_model(experiment_data,niter=8000,nburnin=4000,nchains=4,thin=4)
# Increase the thin argument to 16 for greatly reduced memory usage.

# We can use the fuel_plots() again to produce prediction plots, where removed surveys are shown as black points.
pdf('Plots/nepal.pdf',width=12,height=7.5)
fuel_plots('Nepal',experiment_samples$processed_samples,experiment_data,sampling_bias = TRUE,type='survey')
dev.off()

# We can also use fitted_values() to produce fitted value plots for the removed (forecasted) surveys.
fitted_values('Kerosene',experiment_samples$replicates[,which(model_data$urban$year>cut_off),,],
              lapply(model_data,function(x)filter(x,year>cut_off)),no_overall = FALSE,title='Removed Surveys (2013-2016)')

pdf('Plots/experiment.pdf',width=12,height=9)
fitted_values(fuel_names,experiment_samples$replicates[,which(model_data$urban$year>cut_off),,],
              lapply(model_data,function(x)filter(x,year>cut_off)),no_overall = TRUE,title='Removed Surveys (2013-2016)')
dev.off()


########################
# 5. All country plots #
########################

# Takes a few hours!

# Produce fuel survey prediction plots for all countries with at least one non-zero
# individual fuel observation (even if it was removed before modelling).
pdf('Plots/Country_Check.pdf',width=12,height=7.5)
for(i in 1:length(unique(filtered_data_1$cindex))){
  fuel_plots(country_info$country[sort(unique(filtered_data_1$cindex))][i],all_samples$processed_samples,model_data,sampling_bias = TRUE,type='survey')
}
dev.off()

# Produce prediction plots of the underlying fuel usage in each country.
pdf('Plots/Country_Underlying.pdf',width=12,height=7.5)
for(i in 1:length(country_info$country)){
  fuel_plots(country_info$country[i],all_samples$processed_samples,model_data,sampling_bias = FALSE,type='underlying')
}
dev.off()


