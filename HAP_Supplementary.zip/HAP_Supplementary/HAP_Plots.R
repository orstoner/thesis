##############################
## Household Air Pollution: ##
##   A Hierarchical Model   ##
##############################

# Function to generate fuel usage plots.
fuel_plots=function(plot_country,processed_samples,model_data,sampling_bias=TRUE,type='survey'){
  time_spline=thin_plate_spline(
    input=(model_data$urban$year-mean(model_data$urban$year))/(max(model_data$urban$year)-min(model_data$urban$year)),
    knots=6
  )
  plot_years=1990:2016
  time_index=numeric(length(plot_years))
  for(i in 1:length(plot_years)){
    time_index[i]=which(model_data$urban$year==plot_years[i])[1]
  }
  plot_X=cbind(time_spline$X,time_spline$Z)[time_index,]
  plot_cindex=which(country_info$country==plot_country)
  plot_index=which(model_data$urban$country_index==plot_cindex)
  plot_data=list(model_data[[1]][plot_index,],model_data[[2]][plot_index,],model_data[[3]][plot_index,])
  plot_rindex=plot_data[[1]]$region_index[1]
  plot_phi=processed_samples$phi[,plot_cindex,,]
  
  Y=length(plot_years)
  plot_p=filter(population,country==plot_country)$urban/filter(population,country==plot_country)$total
  plot_p[plot_p>0.99]=0.99
  n_sim=dim(processed_samples$beta)[1]
  plot_nu=plot_mu=plot_omega=plot_v=array(NA,dim=c(n_sim,Y,3,8))
  plot_pi=array(NA,dim=c(n_sim,Y))
  for(i in 1:Y){
    plot_pi[,i]=expit(logit(plot_p[i])+sampling_bias*(processed_samples$beta[,plot_cindex,]%*%plot_X[i,]))
    plot_nu[,i,1:2,]=expit(processed_samples$delta[,plot_cindex,1,1:2,]+processed_samples$delta[,plot_cindex,2,1:2,]*plot_X[i,2])
    for(j in 1:2){
      plot_mu[,i,j,1]=plot_nu[,i,j,1]
      plot_mu[,i,j,2]=plot_nu[,i,j,2]*(1-plot_nu[,i,j,1])
      for(f in 3:8){
        plot_mu[,i,j,f]=plot_nu[,i,j,f]*apply(1-plot_nu[,i,j,1:(f-1)],1,prod)
      }
    }
    plot_mu[,i,3,]=plot_pi[,i]*plot_mu[,i,1,]+(1-plot_pi[,i])*plot_mu[,i,2,]
    
    plot_nu[,i,3,1]=plot_mu[,i,3,1]
    plot_nu[,i,3,2]=plot_mu[,i,3,2]/(1-plot_nu[,i,3,1])
    for(f in 3:8){
      plot_nu[,i,3,f]=plot_mu[,i,3,f]/apply(1-plot_nu[,i,3,1:(f-1)],1,prod)
    }
  }
  
  if(type=='underlying'){
    plot_u=plot_mu
  }
  if(type=='survey'){
    for(i in 1:Y){
      # Truncate nu for numerical stability.
      plot_nu[,i,,]=structure(vapply(plot_nu[,i,,],function(x){min(max(x,expit(-8)),expit(8))}, numeric(1)),dim=dim(plot_nu[,i,,]))
      plot_omega[,i,,]=rbeta(n_sim*3*8,plot_nu[,i,,]*plot_phi,(1-plot_nu[,i,,])*plot_phi)
      
      for(j in 1:3){
        plot_v[,i,j,1]=rbinom(n_sim,1000,plot_omega[,i,j,1])
        plot_v[,i,j,2]=rbinom(n_sim,1000-plot_v[,i,j,1],plot_omega[,i,j,2])
        for(f in 3:8){
          plot_v[,i,j,f]=rbinom(n_sim,1000-apply(plot_v[,i,j,1:(f-1)],1,sum),plot_omega[,i,j,f])
        }
      }
    }
    plot_u=plot_v/1000
  }    
  
  removed_urban=filter(filtered_data_1,cindex==plot_cindex,area==1)
  removed_rural=filter(filtered_data_1,cindex==plot_cindex,area==2)
  removed_overall=filter(filtered_data_1,cindex==plot_cindex,area==3)
  
  w1=ggplot(data.frame(x=plot_years,l=apply(plot_u[,,1,1],2,quantile,0.025),m=apply(plot_u[,,1,1],2,mean),u=apply(plot_u[,,1,1],2,quantile,0.975)))+
    geom_ribbon(aes(x=x,ymin=l,ymax=u),fill=vp[2],alpha=0.5)+
    geom_line(aes(x=x,y=m),col=vp[2])+
    geom_point(data=removed_urban,aes(x=year,y=wood_scaled),col="#22211d")+
    geom_point(data=plot_data[[1]],aes(x=year,y=wood_scaled),col=vp[2])+
    labs(x=NULL,y=NULL) +
    theme(text = element_text(color = "#22211d"),plot.background = element_rect(fill = "#f5f5f2", color = NA),
          panel.background = element_rect(fill = "#f5f5f2", color = NA))+scale_y_continuous(limits=c(0,1))
  
  w2=ggplot(data.frame(x=plot_years,l=apply(plot_u[,,2,1],2,quantile,0.025),m=apply(plot_u[,,2,1],2,mean),u=apply(plot_u[,,2,1],2,quantile,0.975)))+
    geom_ribbon(aes(x=x,ymin=l,ymax=u),fill=vp[3],alpha=0.5)+
    geom_line(aes(x=x,y=m),col=vp[3])+
    geom_point(data=removed_rural,aes(x=year,y=wood_scaled),col="#22211d")+
    geom_point(data=plot_data[[2]],aes(x=year,y=wood_scaled),col=vp[3])+
    labs(x=NULL,y=NULL) +
    theme(text = element_text(color = "#22211d"),plot.background = element_rect(fill = "#f5f5f2", color = NA),
          panel.background = element_rect(fill = "#f5f5f2", color = NA))+scale_y_continuous(limits=c(0,1))
  
  w3=ggplot(data.frame(x=plot_years,l=apply(plot_u[,,3,1],2,quantile,0.025),m=apply(plot_u[,,3,1],2,mean),u=apply(plot_u[,,3,1],2,quantile,0.975)))+
    geom_ribbon(aes(x=x,ymin=l,ymax=u),fill=vp[4],alpha=0.5)+
    geom_line(aes(x=x,y=m),col=vp[4])+
    geom_point(data=removed_overall,aes(x=year,y=wood_scaled),col="#22211d")+
    geom_point(data=plot_data[[3]],aes(x=year,y=wood_scaled),col=vp[4])+
    labs(x=NULL,y=NULL) +
    theme(text = element_text(color = "#22211d"),plot.background = element_rect(fill = "#f5f5f2", color = NA),
          panel.background = element_rect(fill = "#f5f5f2", color = NA))+scale_y_continuous(limits=c(0,1))
  
  cc1=ggplot(data.frame(x=plot_years,l=apply(plot_u[,,1,2],2,quantile,0.025),m=apply(plot_u[,,1,2],2,mean),u=apply(plot_u[,,1,2],2,quantile,0.975)))+
    geom_ribbon(aes(x=x,ymin=l,ymax=u),fill=vp[2],alpha=0.5)+
    geom_line(aes(x=x,y=m),col=vp[2])+
    geom_point(data=removed_urban,aes(x=year,y=charcoal_scaled),col="#22211d")+
    geom_point(data=plot_data[[1]],aes(x=year,y=charcoal_scaled),col=vp[2])+
    labs(x=NULL,y=NULL) +
    theme(text = element_text(color = "#22211d"),plot.background = element_rect(fill = "#f5f5f2", color = NA),
          panel.background = element_rect(fill = "#f5f5f2", color = NA))+scale_y_continuous(limits=c(0,1))
  
  cc2=ggplot(data.frame(x=plot_years,l=apply(plot_u[,,2,2],2,quantile,0.025),m=apply(plot_u[,,2,2],2,mean),u=apply(plot_u[,,2,2],2,quantile,0.975)))+
    geom_ribbon(aes(x=x,ymin=l,ymax=u),fill=vp[3],alpha=0.5)+
    geom_line(aes(x=x,y=m),col=vp[3])+
    geom_point(data=removed_rural,aes(x=year,y=charcoal_scaled),col="#22211d")+
    geom_point(data=plot_data[[2]],aes(x=year,y=charcoal_scaled),col=vp[3])+
    labs(x=NULL,y=NULL) +
    theme(text = element_text(color = "#22211d"),plot.background = element_rect(fill = "#f5f5f2", color = NA),
          panel.background = element_rect(fill = "#f5f5f2", color = NA))+scale_y_continuous(limits=c(0,1))
  
  cc3=ggplot(data.frame(x=plot_years,l=apply(plot_u[,,3,2],2,quantile,0.025),m=apply(plot_u[,,3,2],2,mean),u=apply(plot_u[,,3,2],2,quantile,0.975)))+
    geom_ribbon(aes(x=x,ymin=l,ymax=u),fill=vp[4],alpha=0.5)+
    geom_line(aes(x=x,y=m),col=vp[4])+
    geom_point(data=removed_overall,aes(x=year,y=charcoal_scaled),col="#22211d")+
    geom_point(data=plot_data[[3]],aes(x=year,y=charcoal_scaled),col=vp[4])+
    labs(x=NULL,y=NULL) +
    theme(text = element_text(color = "#22211d"),plot.background = element_rect(fill = "#f5f5f2", color = NA),
          panel.background = element_rect(fill = "#f5f5f2", color = NA))+scale_y_continuous(limits=c(0,1))
  
  c1=ggplot(data.frame(x=plot_years,l=apply(plot_u[,,1,3],2,quantile,0.025),m=apply(plot_u[,,1,3],2,mean),u=apply(plot_u[,,1,3],2,quantile,0.975)))+
    geom_ribbon(aes(x=x,ymin=l,ymax=u),fill=vp[2],alpha=0.5)+
    geom_line(aes(x=x,y=m),col=vp[2])+
    geom_point(data=removed_urban,aes(x=year,y=coal_scaled),col="#22211d")+
    geom_point(data=plot_data[[1]],aes(x=year,y=coal_scaled),col=vp[2])+
    labs(x=NULL,y=NULL) +
    theme(text = element_text(color = "#22211d"),plot.background = element_rect(fill = "#f5f5f2", color = NA),
          panel.background = element_rect(fill = "#f5f5f2", color = NA)
    )+scale_y_continuous(limits=c(0,1))
  
  c2=ggplot(data.frame(x=plot_years,l=apply(plot_u[,,2,3],2,quantile,0.025),m=apply(plot_u[,,2,3],2,mean),u=apply(plot_u[,,2,3],2,quantile,0.975)))+
    geom_ribbon(aes(x=x,ymin=l,ymax=u),fill=vp[3],alpha=0.5)+
    geom_line(aes(x=x,y=m),col=vp[3])+
    geom_point(data=removed_rural,aes(x=year,y=coal_scaled),col="#22211d")+
    geom_point(data=plot_data[[2]],aes(x=year,y=coal_scaled),col=vp[3])+
    labs(x=NULL,y=NULL) +
    theme(text = element_text(color = "#22211d"),plot.background = element_rect(fill = "#f5f5f2", color = NA),
          panel.background = element_rect(fill = "#f5f5f2", color = NA)
    )+scale_y_continuous(limits=c(0,1))
  
  c3=ggplot(data.frame(x=plot_years,l=apply(plot_u[,,3,3],2,quantile,0.025),m=apply(plot_u[,,3,3],2,mean),u=apply(plot_u[,,3,3],2,quantile,0.975)))+
    geom_ribbon(aes(x=x,ymin=l,ymax=u),fill=vp[4],alpha=0.5)+
    geom_line(aes(x=x,y=m),col=vp[4])+
    geom_point(data=removed_overall,aes(x=year,y=coal_scaled),col="#22211d")+
    geom_point(data=plot_data[[3]],aes(x=year,y=coal_scaled),col=vp[4])+
    labs(x=NULL,y=NULL) +
    theme(text = element_text(color = "#22211d"),plot.background = element_rect(fill = "#f5f5f2", color = NA),
          panel.background = element_rect(fill = "#f5f5f2", color = NA)
    )+scale_y_continuous(limits=c(0,1))
  
  cw1=ggplot(data.frame(x=plot_years,l=apply(plot_u[,,1,4],2,quantile,0.025),m=apply(plot_u[,,1,4],2,mean),u=apply(plot_u[,,1,4],2,quantile,0.975)))+
    geom_ribbon(aes(x=x,ymin=l,ymax=u),fill=vp[2],alpha=0.5)+
    geom_line(aes(x=x,y=m),col=vp[2])+
    geom_point(data=removed_urban,aes(x=year,y=cropwaste_scaled),col="#22211d")+
    geom_point(data=plot_data[[1]],aes(x=year,y=cropwaste_scaled),col=vp[2])+
    labs(x=NULL,y=NULL) +
    theme(text = element_text(color = "#22211d"),plot.background = element_rect(fill = "#f5f5f2", color = NA),
          panel.background = element_rect(fill = "#f5f5f2", color = NA)
    )+scale_y_continuous(limits=c(0,1))
  
  cw2=ggplot(data.frame(x=plot_years,l=apply(plot_u[,,2,4],2,quantile,0.025),m=apply(plot_u[,,2,4],2,mean),u=apply(plot_u[,,2,4],2,quantile,0.975)))+
    geom_ribbon(aes(x=x,ymin=l,ymax=u),fill=vp[3],alpha=0.5)+
    geom_line(aes(x=x,y=m),col=vp[3])+
    geom_point(data=removed_rural,aes(x=year,y=cropwaste_scaled),col="#22211d")+
    geom_point(data=plot_data[[2]],aes(x=year,y=cropwaste_scaled),col=vp[3])+
    labs(x=NULL,y=NULL) +
    theme(text = element_text(color = "#22211d"),plot.background = element_rect(fill = "#f5f5f2", color = NA),
          panel.background = element_rect(fill = "#f5f5f2", color = NA)
    )+scale_y_continuous(limits=c(0,1))
  
  cw3=ggplot(data.frame(x=plot_years,l=apply(plot_u[,,3,4],2,quantile,0.025),m=apply(plot_u[,,3,4],2,mean),u=apply(plot_u[,,3,4],2,quantile,0.975)))+
    geom_ribbon(aes(x=x,ymin=l,ymax=u),fill=vp[4],alpha=0.5)+
    geom_line(aes(x=x,y=m),col=vp[4])+
    geom_point(data=removed_overall,aes(x=year,y=cropwaste_scaled),col="#22211d")+
    geom_point(data=plot_data[[3]],aes(x=year,y=cropwaste_scaled),col=vp[4])+
    labs(x=NULL,y=NULL) +
    theme(text = element_text(color = "#22211d"),plot.background = element_rect(fill = "#f5f5f2", color = NA),
          panel.background = element_rect(fill = "#f5f5f2", color = NA)
    )+scale_y_continuous(limits=c(0,1))
  
  d1=ggplot(data.frame(x=plot_years,l=apply(plot_u[,,1,5],2,quantile,0.025),m=apply(plot_u[,,1,5],2,mean),u=apply(plot_u[,,1,5],2,quantile,0.975)))+
    geom_ribbon(aes(x=x,ymin=l,ymax=u),fill=vp[2],alpha=0.5)+
    geom_line(aes(x=x,y=m),col=vp[2])+
    geom_point(data=removed_urban,aes(x=year,y=dung_scaled),col="#22211d")+
    geom_point(data=plot_data[[1]],aes(x=year,y=dung_scaled),col=vp[2])+
    labs(x=NULL,y=NULL) +
    theme(text = element_text(color = "#22211d"),plot.background = element_rect(fill = "#f5f5f2", color = NA),
          panel.background = element_rect(fill = "#f5f5f2", color = NA)
    )+scale_y_continuous(limits=c(0,1))
  
  d2=ggplot(data.frame(x=plot_years,l=apply(plot_u[,,2,5],2,quantile,0.025),m=apply(plot_u[,,2,5],2,mean),u=apply(plot_u[,,2,5],2,quantile,0.975)))+
    geom_ribbon(aes(x=x,ymin=l,ymax=u),fill=vp[3],alpha=0.5)+
    geom_line(aes(x=x,y=m),col=vp[3])+
    geom_point(data=removed_rural,aes(x=year,y=dung_scaled),col="#22211d")+
    geom_point(data=plot_data[[2]],aes(x=year,y=dung_scaled),col=vp[3])+
    labs(x=NULL,y=NULL) +
    theme(text = element_text(color = "#22211d"),plot.background = element_rect(fill = "#f5f5f2", color = NA),
          panel.background = element_rect(fill = "#f5f5f2", color = NA)
    )+scale_y_continuous(limits=c(0,1))
  
  d3=ggplot(data.frame(x=plot_years,l=apply(plot_u[,,3,5],2,quantile,0.025),m=apply(plot_u[,,3,5],2,mean),u=apply(plot_u[,,3,5],2,quantile,0.975)))+
    geom_ribbon(aes(x=x,ymin=l,ymax=u),fill=vp[4],alpha=0.5)+
    geom_line(aes(x=x,y=m),col=vp[4])+
    geom_point(data=removed_overall,aes(x=year,y=dung_scaled),col="#22211d")+
    geom_point(data=plot_data[[3]],aes(x=year,y=dung_scaled),col=vp[4])+
    labs(x=NULL,y=NULL) +
    theme(text = element_text(color = "#22211d"),plot.background = element_rect(fill = "#f5f5f2", color = NA),
          panel.background = element_rect(fill = "#f5f5f2", color = NA)
    )+scale_y_continuous(limits=c(0,1))
  
  e1=ggplot(data.frame(x=plot_years,l=apply(plot_u[,,1,6],2,quantile,0.025),m=apply(plot_u[,,1,6],2,mean),u=apply(plot_u[,,1,6],2,quantile,0.975)))+
    geom_ribbon(aes(x=x,ymin=l,ymax=u),fill=vp[2],alpha=0.5)+
    geom_line(aes(x=x,y=m),col=vp[2])+
    geom_point(data=removed_urban,aes(x=year,y=electricity_scaled),col="#22211d")+
    geom_point(data=plot_data[[1]],aes(x=year,y=electricity_scaled),col=vp[2])+
    labs(x=NULL,y=NULL) +
    theme(text = element_text(color = "#22211d"),plot.background = element_rect(fill = "#f5f5f2", color = NA),
          panel.background = element_rect(fill = "#f5f5f2", color = NA)
    )+scale_y_continuous(limits=c(0,1))
  
  e2=ggplot(data.frame(x=plot_years,l=apply(plot_u[,,2,6],2,quantile,0.025),m=apply(plot_u[,,2,6],2,mean),u=apply(plot_u[,,2,6],2,quantile,0.975)))+
    geom_ribbon(aes(x=x,ymin=l,ymax=u),fill=vp[3],alpha=0.5)+
    geom_line(aes(x=x,y=m),col=vp[3])+
    geom_point(data=removed_rural,aes(x=year,y=electricity_scaled),col="#22211d")+
    geom_point(data=plot_data[[2]],aes(x=year,y=electricity_scaled),col=vp[3])+
    labs(x=NULL,y=NULL) +
    theme(text = element_text(color = "#22211d"),plot.background = element_rect(fill = "#f5f5f2", color = NA),
          panel.background = element_rect(fill = "#f5f5f2", color = NA)
    )+scale_y_continuous(limits=c(0,1))
  
  e3=ggplot(data.frame(x=plot_years,l=apply(plot_u[,,3,6],2,quantile,0.025),m=apply(plot_u[,,3,6],2,mean),u=apply(plot_u[,,3,6],2,quantile,0.975)))+
    geom_ribbon(aes(x=x,ymin=l,ymax=u),fill=vp[4],alpha=0.5)+
    geom_line(aes(x=x,y=m),col=vp[4])+
    geom_point(data=removed_overall,aes(x=year,y=electricity_scaled),col="#22211d")+
    geom_point(data=plot_data[[3]],aes(x=year,y=electricity_scaled),col=vp[4])+
    labs(x=NULL,y=NULL) +
    theme(text = element_text(color = "#22211d"),plot.background = element_rect(fill = "#f5f5f2", color = NA),
          panel.background = element_rect(fill = "#f5f5f2", color = NA)
    )+scale_y_continuous(limits=c(0,1))
  
  lpg1=ggplot(data.frame(x=plot_years,l=apply(plot_u[,,1,7],2,quantile,0.025),m=apply(plot_u[,,1,7],2,mean),u=apply(plot_u[,,1,7],2,quantile,0.975)))+
    geom_ribbon(aes(x=x,ymin=l,ymax=u),fill=vp[2],alpha=0.5)+
    geom_line(aes(x=x,y=m),col=vp[2])+ 
    geom_point(data=removed_urban,aes(x=year,y=lpg_scaled),col="#22211d")+
    geom_point(data=plot_data[[1]],aes(x=year,y=lpg_scaled),col=vp[2])+
    labs(x=NULL,y=NULL) +
    theme(text = element_text(color = "#22211d"),plot.background = element_rect(fill = "#f5f5f2", color = NA),
          panel.background = element_rect(fill = "#f5f5f2", color = NA)
    )+scale_y_continuous(limits=c(0,1))
  
  lpg2=ggplot(data.frame(x=plot_years,l=apply(plot_u[,,2,7],2,quantile,0.025),m=apply(plot_u[,,2,7],2,mean),u=apply(plot_u[,,2,7],2,quantile,0.975)))+
    geom_ribbon(aes(x=x,ymin=l,ymax=u),fill=vp[3],alpha=0.5)+
    geom_line(aes(x=x,y=m),col=vp[3])+
    geom_point(data=removed_rural,aes(x=year,y=lpg_scaled),col="#22211d")+
    geom_point(data=plot_data[[2]],aes(x=year,y=lpg_scaled),col=vp[3])+
    labs(x=NULL,y=NULL) +
    theme(text = element_text(color = "#22211d"),plot.background = element_rect(fill = "#f5f5f2", color = NA),
          panel.background = element_rect(fill = "#f5f5f2", color = NA)
    )+scale_y_continuous(limits=c(0,1))
  
  lpg3=ggplot(data.frame(x=plot_years,l=apply(plot_u[,,3,7],2,quantile,0.025),m=apply(plot_u[,,3,7],2,mean),u=apply(plot_u[,,3,7],2,quantile,0.975)))+
    geom_ribbon(aes(x=x,ymin=l,ymax=u),fill=vp[4],alpha=0.5)+
    geom_line(aes(x=x,y=m),col=vp[4])+
    geom_point(data=removed_overall,aes(x=year,y=lpg_scaled),col="#22211d")+
    geom_point(data=plot_data[[3]],aes(x=year,y=lpg_scaled),col=vp[4])+
    labs(x=NULL,y=NULL) +
    theme(text = element_text(color = "#22211d"),plot.background = element_rect(fill = "#f5f5f2", color = NA),
          panel.background = element_rect(fill = "#f5f5f2", color = NA)
    )+scale_y_continuous(limits=c(0,1))
  
  k1=ggplot(data.frame(x=plot_years,l=apply(plot_u[,,1,8],2,quantile,0.025),m=apply(plot_u[,,1,8],2,mean),u=apply(plot_u[,,1,8],2,quantile,0.975)))+
    geom_ribbon(aes(x=x,ymin=l,ymax=u),fill=vp[2],alpha=0.5)+
    geom_line(aes(x=x,y=m),col=vp[2])+
    geom_point(data=removed_urban,aes(x=year,y=kerosene_scaled),col="#22211d")+
    geom_point(data=plot_data[[1]],aes(x=year,y=kerosene_scaled),col=vp[2])+
    labs(x=NULL,y=NULL) +
    theme(text = element_text(color = "#22211d"),plot.background = element_rect(fill = "#f5f5f2", color = NA),
          panel.background = element_rect(fill = "#f5f5f2", color = NA)
    )+scale_y_continuous(limits=c(0,1))
  
  k2=ggplot(data.frame(x=plot_years,l=apply(plot_u[,,2,8],2,quantile,0.025),m=apply(plot_u[,,2,8],2,mean),u=apply(plot_u[,,2,8],2,quantile,0.975)))+
    geom_ribbon(aes(x=x,ymin=l,ymax=u),fill=vp[3],alpha=0.5)+
    geom_line(aes(x=x,y=m),col=vp[3])+
    geom_point(data=removed_rural,aes(x=year,y=kerosene_scaled),col="#22211d")+
    geom_point(data=plot_data[[2]],aes(x=year,y=kerosene_scaled),col=vp[3])+
    labs(x=NULL,y=NULL) +
    theme(text = element_text(color = "#22211d"),plot.background = element_rect(fill = "#f5f5f2", color = NA),
          panel.background = element_rect(fill = "#f5f5f2", color = NA)
    )+scale_y_continuous(limits=c(0,1))
  
  k3=ggplot(data.frame(x=plot_years,l=apply(plot_u[,,3,8],2,quantile,0.025),m=apply(plot_u[,,3,8],2,mean),u=apply(plot_u[,,3,8],2,quantile,0.975)))+
    geom_ribbon(aes(x=x,ymin=l,ymax=u),fill=vp[4],alpha=0.5)+
    geom_line(aes(x=x,y=m),col=vp[4])+
    geom_point(data=removed_overall,aes(x=year,y=kerosene_scaled),col="#22211d")+
    geom_point(data=plot_data[[3]],aes(x=year,y=kerosene_scaled),col=vp[4])+
    labs(x=NULL,y=NULL) +
    theme(text = element_text(color = "#22211d"),plot.background = element_rect(fill = "#f5f5f2", color = NA),
          panel.background = element_rect(fill = "#f5f5f2", color = NA)
    )+scale_y_continuous(limits=c(0,1))
  
  grid.arrange(arrangeGrob(w1,w2,w3,nrow=1,left='Wood'),
               arrangeGrob(d1,d2,d3,nrow=1,left='Dung'),
               arrangeGrob(cc1,cc2,cc3,nrow=1,left='Charcoal'),
               arrangeGrob(e1,e2,e3,nrow=1,left='Electricity'),
               arrangeGrob(c1,c2,c3,nrow=1,left='Coal'),
               arrangeGrob(lpg1,lpg2,lpg3,nrow=1,left='L.P.G.'),
               arrangeGrob(cw1,cw2,cw3,nrow=1,left='Cropwaste'),
               arrangeGrob(k1,k2,k3,nrow=1,left='Kerosene'),
               nrow=4,
               top=textGrob(plot_country, gp=gpar(fontsize=18)),
               bottom=textGrob('Urban - Rural - Overall', gp=gpar(fontsize=12)))
  
}

# Function to plot the urban proportion observations and spline for a given country.
proportion_plot=function(plot_country,processed_samples,model_data,colour=vp[3]){
  time_spline=thin_plate_spline(
    input=(model_data$urban$year-mean(model_data$urban$year))/(max(model_data$urban$year)-min(model_data$urban$year)),
    knots=6
  )
  plot_years=1990:2016
  time_index=numeric(length(plot_years))
  for(i in 1:length(plot_years)){
    time_index[i]=which(model_data$urban$year==plot_years[i])[1]
  }
  plot_X=cbind(time_spline$X,time_spline$Z)[time_index,]
  plot_cindex=which(country_info$country==plot_country)
  plot_index=which(model_data$urban$country_index==plot_cindex)
  plot_data=list(model_data[[1]][plot_index,],model_data[[2]][plot_index,],model_data[[3]][plot_index,])
  plot_p=(filter(population,country==plot_country)$urban/filter(population,country==plot_country)$total)[1:length(plot_years)]
  plot_p[plot_p>0.99]=0.99
  survey_p=plot_data[[1]]$respondents/plot_data[[3]]$respondents
  n_sim=dim(processed_samples$beta)[1]
  p_samples=expit(t(matrix(rep(logit(plot_p),n_sim),ncol=n_sim))+processed_samples$beta[,plot_cindex,]%*%t(plot_X))
  
  
  ggplot()+
    geom_line(data=data.frame(x=plot_years,y=plot_p),aes(x=x,y=y,colour='colour3'))+
    geom_ribbon(data=data.frame(x=plot_years,l=apply(p_samples,2,quantile,0.025),
                                u=apply(p_samples,2,quantile,0.975)),
                aes(x=x,ymin=l,ymax=u,fill='fill1'),alpha=0.5)+
    geom_line(data=data.frame(x=plot_years,m=apply(p_samples,2,mean)),
              aes(x=x,y=m,colour='colour1'))+
    geom_point(data=data.frame(x=plot_data[[1]]$year,y=survey_p),aes(x=x,y=y,colour='colour2'))+
    labs(x=NULL,y='Urban Proportion',title=plot_country) +
    theme(
      text = element_text(color = "#22211d"),
      plot.background = element_rect(fill = "#f5f5f2", color = NA),
      panel.background = element_rect(fill = "#f5f5f2", color = NA),
      plot.title = element_text(size= 14, hjust=0.01, color = "#4e4d47", margin = margin(b = 0.1, t = 0.1, l = 2, unit = "cm")),
      plot.caption = element_text( size=10, color = "#4e4d47",margin = margin(b = -0.1, t = -0.1, unit = "cm")),
      plot.subtitle = element_text(size= 10, hjust=0.01, color = "#4e4d47", margin = margin(b = 0.2, t = 0.3, l = 2, unit = "cm")),
      legend.background = element_rect(fill = "#f5f5f2", color = NA),legend.position = c(0.75, 0.75)
    )+scale_y_continuous(limits=c(0,1))+scale_colour_manual(name=NULL,values=c('colour1'=colour,'colour2'=colour,'colour3'="#22211d"),
                                                            labels=c('Surveys','Model Prediction','U.N. Estimate'),guide=guide_legend(override.aes = list(
                                                              linetype=c('blank','solid','solid'),shape=c(19,NA,NA)
                                                            )))+
    scale_fill_manual(values=c('fill1'=colour))+guides(fill=FALSE)
  
}


# Function to generate fitted values plots with prediction interval coverages.
fitted_values=function(fuels,replicates,model_data,no_overall=FALSE,title='Fitted Values'){
  fuel_indices=which(fuel_names%in%fuels)
  
  plot_list=list()
  
  for(f in fuel_indices){
    fit1 <- ggplot(data.frame(x=apply(replicates[,,1,f],2,mean),y=unlist(model_data$urban[,c(9,11,13,15,17,19,21,23)[f]])),aes(x=x,y=y)) +
      geom_abline(slope=1,intercept=0, color = "#22211d")+geom_point(colour=vp[2])+
      labs(
        x = expression('Mean Predicted Usage'),
        y = expression('Observed Usage'),
        caption = paste('Coverage:',round(mean(model_data$urban[,c(9,11,13,15,17,19,21,23)[f]]>=apply(replicates[,,1,f],2,quantile,0.025)&
                                                 model_data$urban[,c(9,11,13,15,17,19,21,23)[f]]<=apply(replicates[,,1,f],2,quantile,0.975),na.rm=T),2))
      ) +
      theme(
        text = element_text(color = "#22211d"),
        plot.background = element_rect(fill = "#f5f5f2", color = NA),
        panel.background = element_rect(fill = "#f5f5f2", color = NA),
        plot.title = element_text(size= 14, hjust=0.01, color = "#4e4d47", margin = margin(b = -0.2, t = 0, l = 2, unit = "cm")),
        plot.caption = element_text( size=10, color = "#4e4d47",margin = margin(b = -0.1, t = -0.1, unit = "cm")),
        plot.subtitle = element_text(size= 10, hjust=0.01, color = "#4e4d47", margin = margin(b = 0.2, t = 0.3, l = 2, unit = "cm"))
      ) +scale_x_continuous(limits = c(0,1))+scale_y_continuous(limits=c(0,1))
    
    fit2 <- ggplot(data.frame(x=apply(replicates[,,2,f],2,mean),y=unlist(model_data$rural[,c(9,11,13,15,17,19,21,23)[f]])),aes(x=x,y=y)) +
      geom_abline(slope=1,intercept=0, color = "#22211d")+geom_point(colour=vp[3])+
      labs(
        x = expression('Mean Predicted Usage'),
        y = expression('Observed Usage'),
        caption = paste('Coverage:',round(mean(model_data$rural[,c(9,11,13,15,17,19,21,23)[f]]>=apply(replicates[,,2,f],2,quantile,0.025)&
                                                 model_data$rural[,c(9,11,13,15,17,19,21,23)[f]]<=apply(replicates[,,2,f],2,quantile,0.975),na.rm=T),2))
      ) +
      theme(
        text = element_text(color = "#22211d"),
        plot.background = element_rect(fill = "#f5f5f2", color = NA),
        panel.background = element_rect(fill = "#f5f5f2", color = NA),
        plot.title = element_text(size= 14, hjust=0.01, color = "#4e4d47", margin = margin(b = -0.2, t = 0, l = 2, unit = "cm")),
        plot.caption = element_text( size=10, color = "#4e4d47",margin = margin(b = -0.1, t = -0.1, unit = "cm")),
        plot.subtitle = element_text(size= 10, hjust=0.01, color = "#4e4d47", margin = margin(b = 0.2, t = 0.3, l = 2, unit = "cm"))
      ) +scale_x_continuous(limits = c(0,1))+scale_y_continuous(limits=c(0,1))
    
    if(no_overall==FALSE){
      fit3 <- ggplot(data.frame(x=apply(replicates[,,3,f],2,mean),y=unlist(model_data$overall[,c(9,11,13,15,17,19,21,23)[f]])),aes(x=x,y=y)) +
        geom_abline(slope=1,intercept=0, color = "#22211d")+geom_point(colour=vp[4])+
        labs(
          x = expression('Mean Predicted Usage'),
          y = expression('Observed Usage'),
          caption = paste('Coverage:',round(mean(model_data$overall[,c(9,11,13,15,17,19,21,23)[f]]>=apply(replicates[,,3,f],2,quantile,0.025)&
                                                   model_data$overall[,c(9,11,13,15,17,19,21,23)[f]]<=apply(replicates[,,3,f],2,quantile,0.975),na.rm=T),2))
        ) +
        theme(
          text = element_text(color = "#22211d"),
          plot.background = element_rect(fill = "#f5f5f2", color = NA),
          panel.background = element_rect(fill = "#f5f5f2", color = NA),
          plot.title = element_text(size= 14, hjust=0.01, color = "#4e4d47", margin = margin(b = -0.2, t = 0, l = 2, unit = "cm")),
          plot.caption = element_text( size=10, color = "#4e4d47",margin = margin(b = -0.1, t = -0.1, unit = "cm")),
          plot.subtitle = element_text(size= 10, hjust=0.01, color = "#4e4d47", margin = margin(b = 0.2, t = 0.3, l = 2, unit = "cm"))
        ) +scale_x_continuous(limits = c(0,1))+scale_y_continuous(limits=c(0,1))
    }
    
    if(no_overall==FALSE){
      plot_list[[f-min(fuel_indices)+1]]=arrangeGrob(fit1,fit2,fit3,nrow=1,left=fuel_names[f])
    } 
    if(no_overall==TRUE){
      plot_list[[f-min(fuel_indices)+1]]=arrangeGrob(fit1,fit2,nrow=1,left=fuel_names[f])
    } 
    
  }
  
  if(no_overall==FALSE){
    grid.arrange(grobs=plot_list,ncol=ifelse(length(fuels)<=4,1,2),
                 top=textGrob(title, gp=gpar(fontsize=18)),
                 bottom=textGrob('Urban - Rural - Overall', gp=gpar(fontsize=12)))
  }else{
    grid.arrange(grobs=plot_list,ncol=ifelse(length(fuels)<=4,1,2),
                 top=textGrob(title, gp=gpar(fontsize=18)),
                 bottom=textGrob('Urban - Rural', gp=gpar(fontsize=12)))
  }
  
  
}

# Function to plot a histogram of PSRF values.
psrf_hist=function(psrf,title='Parameter',x_limits=c(1,2),x_label='Potential Scale Reduction Factor',colour='blue',breaks=seq(1,100,0.01)){
  ggplot(data.frame(x=psrf), aes(x=x)) +
    geom_histogram(breaks=breaks,fill=colour) +
    labs(
      title = title,
      x = x_label,
      y = 'Frequency'
    ) +
    theme(
      text = element_text(color = "#22211d"), 
      plot.background = element_rect(fill = "#f5f5f2", color = NA), 
      panel.background = element_rect(fill = "#f5f5f2", color = NA), 
      legend.background = element_rect(fill = "#f5f5f2", color = NA),
      plot.title = element_text(size= 14, hjust=0.01, color = "#4e4d47", margin = margin(b = 0.1, t = 0.1, l = 2, unit = "cm"))
    )+scale_x_continuous(limits=x_limits)
  
}
