##############################
## Household Air Pollution: ##
##   A Hierarchical Model   ##
##############################

# This script sets up the data so that it can be modelled.

# Threshold for incompleteness (see supplementary document) above which surveys will be removed.
incomplete_threshold=0.15 

# Filter out surveys with no non-zero observations for individual fuels.
filtered_data_1=filter(survey_data,total_fuels>0) 

# Divide fuel observations by their sum or by 1-(no response+unlisted fuel+no cooking),
# whichever is greater. This ensures that the sum of individual fuel values can't exceed one.
scaling_factor <- apply(cbind(filtered_data_1$total_fuels,1-filtered_data_1$total_others),1,max)

filtered_data_1$wood_scaled=filtered_data_1$wood/scaling_factor
filtered_data_1$charcoal_scaled=filtered_data_1$charcoal/scaling_factor
filtered_data_1$coal_scaled=filtered_data_1$coal/scaling_factor
filtered_data_1$cropwaste_scaled=filtered_data_1$cropwaste/scaling_factor
filtered_data_1$dung_scaled=filtered_data_1$dung/scaling_factor
filtered_data_1$electricity_scaled=filtered_data_1$electricity/scaling_factor
filtered_data_1$lpg_scaled=filtered_data_1$lpg/scaling_factor
filtered_data_1$kerosene_scaled=filtered_data_1$kerosene/scaling_factor
filtered_data_1$other_scaled=1-(filtered_data_1$wood_scaled+filtered_data_1$charcoal_scaled+filtered_data_1$coal_scaled+
                                  filtered_data_1$cropwaste_scaled+filtered_data_1$dung_scaled+
                                filtered_data_1$electricity_scaled+filtered_data_1$kerosene_scaled+filtered_data_1$lpg_scaled)

# Filter out surveys above the 'incompleteness' threshold.
removed_data=filter(filtered_data_1,total_others>incomplete_threshold)
filtered_data_2=filter(filtered_data_1,total_others<=incomplete_threshold)

n_id=length(unique(filtered_data_2$id)) # Number of unique surveys.

# Put the data into a list of equal size data frames for modelling.
empty=data_frame(id=rep(NA,n_id),country=rep('NA',n_id),country_index=rep(NA,n_id),region=rep('NA',n_id),
                 region_index=rep(NA,n_id),year=rep(NA,n_id),urban_proportion=rep(NA,n_id),respondents=rep(NA,n_id),
                 wood_scaled=rep(NA,n_id),wood_count=rep(NA,n_id),charcoal_scaled=rep(NA,n_id),charcoal_count=rep(NA,n_id),
                 coal_scaled=rep(NA,n_id),coal_count=rep(NA,n_id),cropwaste_scaled=rep(NA,n_id),cropwaste_count=rep(NA,n_id),
                 dung_scaled=rep(NA,n_id),dung_count=rep(NA,n_id),electricity_scaled=rep(NA,n_id),electricity_count=rep(NA,n_id),
                 lpg_scaled=rep(NA,n_id),lpg_count=rep(NA,n_id),kerosene_scaled=rep(NA,n_id),kerosene_count=rep(NA,n_id),
                 other_scaled=rep(NA,n_id),other_count=rep(NA,n_id))

model_data=list(urban=empty,rural=empty,overall=empty)
model_data[[1]]$id=model_data[[2]]$id=model_data[[3]]$id=unique(filtered_data_2$id)

# Convert the proportions into counts for modelling.
for(i in 1:n_id){
  for(j in 1:3){
    data_row=which(filtered_data_2$id==model_data[[j]]$id[i]&filtered_data_2$area==j)[1]
    if(!is.na(data_row)){
      model_data[[1]]$country[i]=model_data[[2]]$country[i]=
        model_data[[3]]$country[i]=filtered_data_2$whoname[data_row]
      model_data[[1]]$country_index[i]=model_data[[2]]$country_index[i]=
        model_data[[3]]$country_index[i]=filtered_data_2$cindex[data_row]
      model_data[[1]]$region[i]=model_data[[2]]$region[i]=
        model_data[[3]]$region[i]=as.character(filtered_data_2$region[data_row])
      model_data[[1]]$region_index[i]=model_data[[2]]$region_index[i]=
        model_data[[3]]$region_index[i]=filtered_data_2$region[data_row]
      model_data[[1]]$year[i]=model_data[[2]]$year[i]=
        model_data[[3]]$year[i]=filtered_data_2$year[data_row]
      model_data[[1]]$urban_proportion[i]=model_data[[2]]$urban_proportion[i]=
        model_data[[3]]$urban_proportion[i]=filtered_data_2$urban_proportion[data_row]
      model_data[[j]]$respondents[i]=filtered_data_2$totalrespondents[data_row]
      model_data[[j]]$electricity_scaled[i]=filtered_data_2$electricity_scaled[data_row]
      model_data[[j]]$electricity_count[i]=floor(filtered_data_2$electricity_scaled[data_row]*1000)
      model_data[[j]]$kerosene_scaled[i]=filtered_data_2$kerosene_scaled[data_row]
      model_data[[j]]$kerosene_count[i]=floor(filtered_data_2$kerosene_scaled[data_row]*1000)
      model_data[[j]]$lpg_scaled[i]=filtered_data_2$lpg_scaled[data_row]
      model_data[[j]]$lpg_count[i]=floor(filtered_data_2$lpg_scaled[data_row]*1000)
      model_data[[j]]$wood_scaled[i]=filtered_data_2$wood_scaled[data_row]
      model_data[[j]]$wood_count[i]=floor(filtered_data_2$wood_scaled[data_row]*1000)
      model_data[[j]]$charcoal_scaled[i]=filtered_data_2$charcoal_scaled[data_row]
      model_data[[j]]$charcoal_count[i]=floor(filtered_data_2$charcoal_scaled[data_row]*1000)
      model_data[[j]]$coal_scaled[i]=filtered_data_2$coal_scaled[data_row]
      model_data[[j]]$coal_count[i]=floor(filtered_data_2$coal_scaled[data_row]*1000)
      model_data[[j]]$cropwaste_scaled[i]=filtered_data_2$cropwaste_scaled[data_row]
      model_data[[j]]$cropwaste_count[i]=floor(filtered_data_2$cropwaste_scaled[data_row]*1000)
      model_data[[j]]$dung_scaled[i]=filtered_data_2$dung_scaled[data_row]
      model_data[[j]]$dung_count[i]=floor(filtered_data_2$dung_scaled[data_row]*1000)
      model_data[[j]]$other_scaled[i]=filtered_data_2$other_scaled[data_row]
      model_data[[j]]$other_count[i]=floor(filtered_data_2$other_scaled[data_row]*1000)
    }
  }
}
