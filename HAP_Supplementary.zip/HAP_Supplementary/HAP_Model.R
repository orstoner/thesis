##############################
## Household Air Pollution: ##
##   A Hierarchical Model   ##
##############################

run_model=function(model_data,niter=2000,nburnin=1000,nchains=4,thin=1){
  
  # Add the Beta-Binomial distribution to NIMBLE (required functions
  # are in HAP_Functions.R).
  registerDistributions(list(dbetabin=list(
    BUGSdist='dbetabin(mu,phi,size,weight)',discrete=TRUE)))
  
  # Setup a thin plate spline with 6 knots.
  time_spline=thin_plate_spline(
    input=(model_data$urban$year-mean(model_data$urban$year))/(max(model_data$urban$year)-min(model_data$urban$year)),
    knots=6
  )
  
  # The model is written in the BUGS language.
  nimble_code=nimbleCode({
    for(i in 1:N){
      # Urban proportion.
      pi[i] <- ilogit(logit(p[i])+beta[cindex[i],1]+beta[cindex[i],2]*X[i,2]+
                        beta[cindex[i],3]*Z[i,1]+beta[cindex[i],4]*Z[i,2]+
                        beta[cindex[i],5]*Z[i,3]+beta[cindex[i],6]*Z[i,4]+
                        beta[cindex[i],7]*Z[i,5]+beta[cindex[i],8]*Z[i,6])
      for(j in 1:2){ # Urban and rural usage models.
        for(f in 1:8){
          # Beta-Binomial means.
          nu[i,j,f] <- ilogit(delta[cindex[i],1,j,f]+delta[cindex[i],2,j,f]*X[i,2])
        }
        mu[i,j,1] <- nu[i,j,1] # Wood.
        for(f in 2:8){
          mu[i,j,f] <- nu[i,j,f]*prod(1-nu[i,j,1:(f-1)]) # Everything else.
        }
      }
      for(f in 1:8){
        mu[i,3,f] <- pi[i]*mu[i,1,f]+(1-pi[i])*mu[i,2,f] # Overall means.
      }
      nu[i,3,1] <- mu[i,3,1] # Wood.
      for(f in 2:8){ # Everything else.
        nu[i,3,f] <- mu[i,3,f]/prod(1-nu[i,3,1:(f-1)])
      }
      for(j in 1:3){ # Data conditional likelihoods.
        y[i,j,1] ~ dbetabin(nu[i,j,1],phi[cindex[i],j,1],1000,weight[i,j,1]) # Wood.
        for(f in 2:8){ # Everything else.
          y[i,j,f] ~ dbetabin(nu[i,j,f],phi[cindex[i],j,f],1000-sum(y[i,j,1:(f-1)]),weight[i,j,f])
        }
      }
    }
    # Regional effect priors.
    for(f in 1:8){
      for(r in 1:R){
        for(i in 1:2){
          for(j in 1:2){
            gamma[r,i,j,f] ~ dnorm(0,sd=10) # Intercept and slope.
          } 
        }
        for(j in 1:3){
          psi[r,j,f] ~ dnorm(0,sd=2) # Regional dispersion effect.
        } 
      }
      # Covariance matrices.
      for(r in 1:R){
        Sigma_delta_1[1:2,1:2,r,f] ~ dinvwish(S=scale_delta[1:2,1:2],df=5)
        Sigma_delta_2[1:2,1:2,r,f] ~ dinvwish(S=scale_delta[1:2,1:2],df=5)
        Sigma_epsilon[1:3,1:3,r,f] ~ dinvwish(S=scale_epsilon[1:3,1:3],df=6)
      }
    }
    # Country effect models.
    for(c in 1:C){
      for(f in 1:8){
        delta[c,1,1:2,f] ~ dmnorm(gamma[crindex[c],1,1:2,f],cov=Sigma_delta_1[1:2,1:2,crindex[c],f])
        delta[c,2,1:2,f] ~ dmnorm(gamma[crindex[c],2,1:2,f],cov=Sigma_delta_2[1:2,1:2,crindex[c],f])
        epsilon[c,1:3,f] ~ dmnorm(psi[crindex[c],1:3,f],cov=Sigma_epsilon[1:3,1:3,crindex[c],f])
        for(j in 1:3){
          phi[c,j,f] <- exp(epsilon[c,j,f]) # Dispersion parameters.
        }
      }
      # Urban proportion country effect.
      beta[c,1] ~ dnorm(0,sd=1)
      beta[c,2] ~ dnorm(0,sd=1)
      for(k in 1:6){
        beta[c,k+2] ~ dnorm(0,sd=sigma[c])
      }
      sigma[c] ~ T(dnorm(0,1),0,) # Smoothing penalty.
    }
  })
  
  N=dim(model_data$urban)[1] # Number of surveys.
  C=194 # Number of countries.
  R=6 # Number of WHO regions.
  
  # NIMBLE takes in constants (things like indices which don't relate
  # to the probabilistic model) separately from the data.
  nimble_constants=list(N=N,C=C,R=R,cindex=model_data$urban$country_index,
                        rindex=model_data$urban$region_index,
                        crindex=as.numeric(as.factor(country_info$region)))
  
  # Scale parameters for the covariance matrix priors.
  scale_delta=rbind(c(4,1),c(1,4))
  scale_epsilon=rbind(c(4,1,1),c(1,4,1),c(1,1,4))
  
  # Data are things like the observed values and often covariates or
  # structure matrices for splines.
  nimble_data=list(y=array(NA,dim=c(N,3,8)),weight=array(1,dim=c(N,3,8)),
                   p=model_data$urban$urban_proportion,scale_delta=scale_delta,
                   scale_epsilon=scale_epsilon,X=time_spline$X,Z=time_spline$Z)
  for(j in 1:3){
    nimble_data$y[,j,]=as.matrix(model_data[[j]][,c(10,12,14,16,18,20,22,24)])
  } 
  
  # Adjust U.N. urban proportion estimates which are close to 1.
  nimble_data$p[nimble_data$p>0.99]=0.99
  
  for(i in 1:N){ # Trick to prevent sampling of wholly missing survey areas (urban/rural/overall).
    for(j in 1:3){
      if(sum(is.na(nimble_data$y[i,j,]))==8){
        nimble_data$weight[i,j,]=0
        nimble_data$y[i,j,]=0
      }
    }
  }
  
  # Initialise model parameters.
  nimble_inits=list(c1=inits_function(nimble_data,seed=seed2[1],N,C,R,scale_delta,scale_epsilon),
                    c2=inits_function(nimble_data,seed=seed2[2],N,C,R,scale_delta,scale_epsilon),
                    c3=inits_function(nimble_data,seed=seed2[3],N,C,R,scale_delta,scale_epsilon),
                    c4=inits_function(nimble_data,seed=seed2[4],N,C,R,scale_delta,scale_epsilon))
  
  # Construct the model object (which can be manipulated to obtain prior probabilities etc.)
  nimble_model=nimbleModel(nimble_code,nimble_constants,nimble_data,nimble_inits)
  
  # Compile the model object.
  nimble_compiled_model=compileNimble(nimble_model)
  
  # Configure the MCMC, telling it whether to look for conjugate (Gibbs) relationships
  # and what parameters to save.
  nimble_mcmc_config=configureMCMC(nimble_model,useConjugacy = FALSE,
                                   monitors = c('gamma','beta','delta','epsilon','psi','nu','pi',
                                                'Sigma_delta_1','Sigma_delta_2','Sigma_epsilon','sigma'))
  # Build the MCMC object.
  nimble_mcmc=buildMCMC(nimble_mcmc_config)
  
  # Compile the MCMC object.
  nimble_compiled_mcmc=compileNimble(nimble_mcmc)
  
  # Run the MCMC.
  samples=runMCMC(nimble_compiled_mcmc,niter=niter,nburnin=nburnin,
                         nchains=nchains,thin=thin,inits=nimble_inits[1:nchains],
                         samplesAsCodaMCMC = TRUE,setSeed = seed2[1:nchains])
  
  # Combine the chains into one matrix.
  combined_samples=do.call('rbind',samples)
  n_sim=dim(combined_samples)[1]
  
  output=list(mcmc=samples,processed_samples=list())
  
  # To save memory we only save a selection of the model parameters for plotting etc.
  
  nu_index=which(dimnames(combined_samples)[[2]]=='nu[1, 1, 1]'):which(dimnames(combined_samples)[[2]]==paste('nu[',N,', 3, 8]',sep=''))
  output$processed_samples$nu=array(combined_samples[,nu_index],dim=c(n_sim,N,3,8))
  
  epsilon_index=which(dimnames(combined_samples)[[2]]=='epsilon[1, 1, 1]'):which(dimnames(combined_samples)[[2]]=='epsilon[194, 3, 8]')
  output$processed_samples$phi=exp(array(combined_samples[,epsilon_index],dim=c(n_sim,C,3,8)))
  
  beta_index=which(dimnames(combined_samples)[[2]]=='beta[1, 1]'):which(dimnames(combined_samples)[[2]]=='beta[194, 8]')
  output$processed_samples$beta=array(combined_samples[,beta_index],dim=c(n_sim,C,8))
  
  delta_index=which(dimnames(combined_samples)[[2]]=='delta[1, 1, 1, 1]'):which(dimnames(combined_samples)[[2]]=='delta[194, 2, 2, 8]')
  output$processed_samples$delta=array(combined_samples[,delta_index],dim=c(n_sim,C,2,2,8))
  
  # Simulate replicates of the observed proportions.
  v_replicates=array(NA,dim=c(n_sim,N,3,8))
  v_replicates[,,,1]=rbinom(n_sim*N*3,1000,
                            rbeta(n_sim*N*3,output$processed_samples$nu[,,,1]*output$processed_samples$phi[,nimble_constants$cindex,,1],
                                  (1-output$processed_samples$nu[,,,1])*output$processed_samples$phi[,nimble_constants$cindex,,1]))
  v_replicates[,,,2]=rbinom(n_sim*N*3,1000-v_replicates[,,,1],
                            rbeta(n_sim*N*3,output$processed_samples$nu[,,,2]*output$processed_samples$phi[,nimble_constants$cindex,,2],
                                  (1-output$processed_samples$nu[,,,2])*output$processed_samples$phi[,nimble_constants$cindex,,2]))
  v_replicates[,,,3]=rbinom(n_sim*N*3,1000-v_replicates[,,,1]-v_replicates[,,,2],
                            rbeta(n_sim*N*3,output$processed_samples$nu[,,,3]*output$processed_samples$phi[,nimble_constants$cindex,,3],
                                  (1-output$processed_samples$nu[,,,3])*output$processed_samples$phi[,nimble_constants$cindex,,3]))
  v_replicates[,,,4]=rbinom(n_sim*N*3,1000-v_replicates[,,,1]-v_replicates[,,,2]-v_replicates[,,,3],
                            rbeta(n_sim*N*3,output$processed_samples$nu[,,,4]*output$processed_samples$phi[,nimble_constants$cindex,,4],
                                  (1-output$processed_samples$nu[,,,4])*output$processed_samples$phi[,nimble_constants$cindex,,4]))
  v_replicates[,,,5]=rbinom(n_sim*N*3,1000-v_replicates[,,,1]-v_replicates[,,,2]-v_replicates[,,,3]-v_replicates[,,,4],
                            rbeta(n_sim*N*3,output$processed_samples$nu[,,,5]*output$processed_samples$phi[,nimble_constants$cindex,,5],
                                  (1-output$processed_samples$nu[,,,5])*output$processed_samples$phi[,nimble_constants$cindex,,5]))
  v_replicates[,,,6]=rbinom(n_sim*N*3,1000-v_replicates[,,,1]-v_replicates[,,,2]-v_replicates[,,,3]-v_replicates[,,,4]-v_replicates[,,,5],
                            rbeta(n_sim*N*3,output$processed_samples$nu[,,,6]*output$processed_samples$phi[,nimble_constants$cindex,,6],
                                  (1-output$processed_samples$nu[,,,6])*output$processed_samples$phi[,nimble_constants$cindex,,6]))
  v_replicates[,,,7]=rbinom(n_sim*N*3,1000-v_replicates[,,,1]-v_replicates[,,,2]-v_replicates[,,,3]-v_replicates[,,,4]-v_replicates[,,,5]-v_replicates[,,,6],
                            rbeta(n_sim*N*3,output$processed_samples$nu[,,,7]*output$processed_samples$phi[,nimble_constants$cindex,,7],
                                  (1-output$processed_samples$nu[,,,7])*output$processed_samples$phi[,nimble_constants$cindex,,7]))
  v_replicates[,,,8]=rbinom(n_sim*N*3,1000-v_replicates[,,,1]-v_replicates[,,,2]-v_replicates[,,,3]-v_replicates[,,,4]-v_replicates[,,,5]-v_replicates[,,,6]-v_replicates[,,,7],
                            rbeta(n_sim*N*3,output$processed_samples$nu[,,,8]*output$processed_samples$phi[,nimble_constants$cindex,,8],
                                  (1-output$processed_samples$nu[,,,8])*output$processed_samples$phi[,nimble_constants$cindex,,8]))

  output$replicates=v_replicates/1000
  
  return(output)
  
}

