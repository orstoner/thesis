##############################
## Household Air Pollution: ##
##   A Hierarchical Model   ##
##############################

# Function to generate initial values for the MCMC chains.
inits_function=function(data,seed,N,C,R,scale_delta,scale_epsilon){
  
  set.seed(seed)
  
  inits=list(y=array(NA,dim=c(N,3,8)),gamma=array(rnorm(R*2*2*8,0,2),dim=c(R,2,2,8)),delta=array(rnorm(C*2*2*8,0,0.5),dim=c(C,2,2,8)),
             psi=array(rnorm(R*3*8,0,2),dim=c(R,3,8)),epsilon=array(rnorm(C*3*8,0,0.5),dim=c(C,3,8)),
             beta=array(rnorm(C*8,0,0.1),dim=c(C,8)),Sigma_delta_1=array(NA,dim=c(2,2,6,8)),
             Sigma_delta_2=array(NA,dim=c(2,2,6,8)),Sigma_epsilon=array(NA,dim=c(3,3,6,8)),
             sigma=qnorm(runif(C,0.5,1),0,1))
  for(f in 1:8){
    for(r in 1:R){
      inits$Sigma_delta_1[,,r,f]=rinvwish_chol(1,chol(scale_delta),5,scale_param=1)
      inits$Sigma_delta_2[,,r,f]=rinvwish_chol(1,chol(scale_delta),5,scale_param=1)
      inits$Sigma_epsilon[,,r,f]=rinvwish_chol(1,chol(scale_epsilon),5,scale_param=1)
    }
  }
  for(i in 1:N){
    for(j in 1:3){
      for(f in 1:8){
        if(is.na(data$y[i,j,f])){
          inits$y[i,j,f]=0
        }
      }
    }
  }
  return(inits)
}

# Beta-Binomial probability (log) density function.
dbetabin=nimbleFunction(run=function(x=double(0),mu=double(0),phi=double(0),size=double(0),weight=double(0),log=integer(0)){
  returnType(double(0))
  phi <- min(phi,1e+05) # Hard upper limit on phi for computational stability.
  if(x>=0&x<=size){
    return(weight*(lgamma(size+1)+lgamma(x+mu*phi)+lgamma(size-x+(1-mu)*phi)+lgamma(phi)-
             lgamma(size+phi)-lgamma(mu*phi)-lgamma((1-mu)*phi)-lgamma(size-x+1)-lgamma(x+1)))
  }else{
    return(-Inf)
  }
})

# Beta-Binomial simulation function.
rbetabin=nimbleFunction(run=function(n=integer(0),mu=double(0),phi=double(0),size=double(0),weight=double(0)){
  phi <- min(phi,1e+05) # Hard upper limit on phi for computational stability.
  pi=rbeta(1,mu*phi,(1-mu)*phi)
  returnType(double(0))
  return(rbinom(1,size,pi))
})

# Function to set up a thin-plate spline.
thin_plate_spline=function(input,knots){
  n <- length(input)
  X <- cbind(rep(1, n), input)
  knots <- quantile(unique(input), seq(0, 1, length = (knots + 2))[-c(1, (knots + 2))])
  Z_K <- (abs(outer(input, knots, "-")))^3
  OMEGA_all <- (abs(outer(knots, knots, "-")))^3
  svd.OMEGA_all <- svd(OMEGA_all)
  sqrt.OMEGA_all <- t(svd.OMEGA_all$v %*% (t(svd.OMEGA_all$u) * sqrt(svd.OMEGA_all$d)))
  Z <- t(solve(sqrt.OMEGA_all, t(Z_K)))
  return(list(X=X,Z=Z))
}
